#include "structures.h"

void printAST(is_node* node, int tabs);
